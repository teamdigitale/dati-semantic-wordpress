<?php

// API Base URL for the main application
define('WP_SCHEMA_API_BASE_URL', 'https://ndc-dev.apps.cloudpub.testedev.istat.it/api/');

// Matomo Analytics API Configuration
define('MATOMO_API_URL', 'https://analytics.istat.it/?module=API'); // Base URL for Matomo API
define('MATOMO_TOKEN', 'ef124ba7d106b8f55d64670f506b8ac6'); // Authentication token for Matomo API
define('MATOMO_SITE_ID', 33); // ID of the site in Matomo
define('MATOMO_USER', 'dtd'); // Username for Matomo API authentication
define('MATOMO_PASS', 'NDCstats2024'); // Password for Matomo API authentication

// Mapping status chips
function get_status_chip($status) {
    $status = strtolower($status);
    switch ($status) {
        case 'catalogued':
        case 'published':
            return '<span class="chip-status chip-green">Stabile</span>';
        case 'archived':
            return '<span class="chip-status chip-grey">Archiviato</span>';
        case 'closed access':
            return '<span class="chip-status chip-grey">Accesso ristretto</span>';
        case 'initial draft':
        case 'draft':
        case 'final draft':
        case 'intermediate draft':
        case 'submitted':
            return '<span class="chip-status chip-grey">Bozza</span>';
        default:
            return '';
    }
}