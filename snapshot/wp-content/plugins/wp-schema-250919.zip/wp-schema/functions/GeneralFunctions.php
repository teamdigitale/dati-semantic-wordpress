<?php 
function fetch_stats($year = null) {
    // Se l'anno non è fornito, utilizza l'anno corrente
    if (is_null($year)) {
        $year = date('Y');
    }

    $api_url = 'https://ndc-dev.apps.cloudpub.testedev.istat.it/api/semantic-assets/stats?year=' . urlencode($year);
    $response = file_get_contents($api_url);
    return json_decode($response, true);
}

function formatValue($value) {
    // Aggiunge il segno + ai valori >= 0
    return ($value >= 0 ? '+' : '') . $value;
}

function GetStatsTotal($year = null) {
    $stats = fetch_stats($year);
    return $stats['total']['current'];
}

function GetStatsTotalOverLastYear($year = null) {
    $stats = fetch_stats($year);
    return formatValue($stats['total']['incrementOverLastYear']);
}

function GetStatsTotalPercentageOverLastYear($year = null) {
    $stats = fetch_stats($year);
    return formatValue($stats['total']['incrementPercentageOverLastYear']);
}

function GetStatsCV($year = null) {
    $stats = fetch_stats($year);
    return $stats['controlledVocabulary']['current'];
}

function GetStatsCVOverLastYear($year = null) {
    $stats = fetch_stats($year);
    return formatValue($stats['controlledVocabulary']['incrementOverLastYear']);
}

function GetStatsCVPercentageOverLastYear($year = null) {
    $stats = fetch_stats($year);
    return formatValue($stats['controlledVocabulary']['incrementPercentageOverLastYear']);
}

function GetStatsOntology($year = null) {
    $stats = fetch_stats($year);
    return $stats['ontology']['current'];
}

function GetStatsOntologyOverLastYear($year = null) {
    $stats = fetch_stats($year);
    return formatValue($stats['ontology']['incrementOverLastYear']);
}

function GetStatsOntologyPercentageOverLastYear($year = null) {
    $stats = fetch_stats($year);
    return formatValue($stats['ontology']['incrementPercentageOverLastYear']);
}

function GetStatsSchema($year = null) {
    $stats = fetch_stats($year);
    return $stats['schema']['current'];
}

function GetStatsSchemaOverLastYear($year = null) {
    $stats = fetch_stats($year);
    return formatValue($stats['schema']['incrementOverLastYear']);
}

function GetStatsSchemaPercentageOverLastYear($year = null) {
    $stats = fetch_stats($year);
    return formatValue($stats['schema']['incrementPercentageOverLastYear']);
}

function PrintAllStats($year = null) {
    $stats = fetch_stats($year);
    echo "<pre>";
    print_r($stats);
    echo "</pre>";
}