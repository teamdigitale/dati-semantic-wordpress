<?php 

add_shortcode('get-resource-details', 'render_resource_details');
add_shortcode('get-resource-array', 'render_resource_array');
add_shortcode('get-resource-debug', 'render_resource_debug');

// Individual field shortcodes
add_shortcode('resource-assetIri', 'render_resource_assetIri');
add_shortcode('resource-title', 'render_resource_title');
add_shortcode('resource-description', 'render_resource_description');
add_shortcode('resource-type', 'render_resource_type');
add_shortcode('resource-modifiedOn', 'render_resource_modifiedOn');
add_shortcode('resource-issuedOn', 'render_resource_issuedOn');
add_shortcode('resource-versionInfo', 'render_resource_versionInfo');
add_shortcode('resource-rightsHolder', 'render_resource_rightsHolder');
add_shortcode('resource-labels', 'render_resource_labels');
add_shortcode('resource-status', 'render_resource_status');
add_shortcode('resource-contactPoint-iri', 'render_resource_contactPoint_iri');
add_shortcode('resource-contactPoint-summary', 'render_resource_contactPoint_summary');
add_shortcode('resource-publishers', 'render_resource_publishers');
add_shortcode('resource-creators', 'render_resource_creators');
add_shortcode('resource-languages', 'render_resource_languages');
add_shortcode('resource-themes', 'render_resource_themes');
add_shortcode('resource-type-button', 'render_resource_type_button');
add_shortcode('resource-type-css', 'render_resource_type_css');
add_shortcode('resource-accrualPeriodicity', 'render_resource_accrualPeriodicity');
add_shortcode('resource-prefix', 'render_resource_prefix');
add_shortcode('resource-projects', 'render_resource_projects');

// Global variable to store the current resource data
global $current_resource_data;
$current_resource_data = null;

function render_resource_details() {
    global $current_resource_data;
    
    if (!isset($_GET['uri']) || empty($_GET['uri'])) {
        return '';
    }

    $uri = $_GET['uri'];
    $encoded_uri = urlencode($uri);
    $cache_key = md5($uri);
    
    // Try to get from cache first
    $data = get_resource_transient($cache_key);
    $cache_hit = ($data !== false);
    
    if (!$cache_hit) {
        // Cache miss - call API
        if (!defined('WP_SCHEMA_API_BASE_URL')) {
            return '';
        }
        
        $api_url = WP_SCHEMA_API_BASE_URL . 'semantic-assets/by-iri?iri=' . $encoded_uri;
        $response = wp_remote_get($api_url);
        
        if (is_wp_error($response)) {
            return '';
        }
        
        $status_code = wp_remote_retrieve_response_code($response);
        if ($status_code !== 200) {
            return '';
        }
        
        $body = wp_remote_retrieve_body($response);
        if (empty($body)) {
            return '';
        }
        
        $data = json_decode($body, true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            return '';
        }
        
        // Save to cache for 1 hour
        set_resource_transient($cache_key, $data, 3600);
    }
    
    // Store data globally for other shortcodes
    $current_resource_data = $data;
    
    // Clean expired cache entries
    purge_expired_resource_transients();
    
    return '';
}

function render_resource_array() {
    global $current_resource_data;
    
    if ($current_resource_data === null) {
        return '<div class="error">Nessun dato risorsa disponibile. Usa prima [get-resource-details].</div>';
    }
    
    ob_start();
    echo '<h3>Dati Risorsa:</h3>';
    echo '<pre>';
    print_r($current_resource_data);
    echo '</pre>';
    return ob_get_clean();
}

function render_resource_debug() {
    global $current_resource_data;
    
    ob_start();
    echo '<h3>Debug Informazioni:</h3>';
    echo '<div class="debug-info">';
    
    // Check if URI parameter exists
    if (isset($_GET['uri']) && !empty($_GET['uri'])) {
        echo '<p><strong>✅ URI presente:</strong> ' . htmlspecialchars($_GET['uri']) . '</p>';
        
        // Check API configuration
        if (defined('WP_SCHEMA_API_BASE_URL')) {
            echo '<p><strong>✅ Configurazione API:</strong> ' . htmlspecialchars(WP_SCHEMA_API_BASE_URL) . '</p>';
        } else {
            echo '<p><strong>❌ Configurazione API:</strong> Non definita</p>';
        }
        
        // Check cache status
        $uri = $_GET['uri'];
        $cache_key = md5($uri);
        $cached_data = get_resource_transient($cache_key);
        
        if ($cached_data !== false) {
            echo '<p><strong>✅ Cache:</strong> Dati presenti in cache</p>';
        } else {
            echo '<p><strong>❌ Cache:</strong> Nessun dato in cache</p>';
        }
        
        // Check if data is loaded
        if ($current_resource_data !== null) {
            echo '<p><strong>✅ Dati caricati:</strong> Sì</p>';
            echo '<p><strong>📊 Campi disponibili:</strong> ' . count($current_resource_data) . '</p>';
            
            // Show available fields
            echo '<p><strong>📋 Campi principali:</strong></p>';
            echo '<ul>';
            $main_fields = ['title', 'description', 'type', 'modifiedOn', 'issuedOn', 'rightsHolder', 'themes'];
            foreach ($main_fields as $field) {
                if (isset($current_resource_data[$field])) {
                    echo '<li><strong>' . $field . ':</strong> Presente</li>';
                } else {
                    echo '<li><strong>' . $field . ':</strong> Non presente</li>';
                }
            }
            echo '</ul>';
        } else {
            echo '<p><strong>❌ Dati caricati:</strong> No - Usa [get-resource-details] prima</p>';
        }
        
    } else {
        echo '<p><strong>❌ URI:</strong> Parametro mancante</p>';
    }
    
    // Check cache table
    global $wpdb;
    $table = $wpdb->prefix . 'ResourceTransients';
    $table_exists = $wpdb->get_var("SHOW TABLES LIKE '$table'") == $table;
    
    if ($table_exists) {
        $cache_count = $wpdb->get_var("SELECT COUNT(*) FROM $table");
        echo '<p><strong>✅ Tabella cache:</strong> Esiste (' . $cache_count . ' elementi)</p>';
    } else {
        echo '<p><strong>❌ Tabella cache:</strong> Non esiste</p>';
    }
    
    echo '</div>';
    return ob_get_clean();
}

// Individual field shortcode functions
function render_resource_assetIri() {
    global $current_resource_data;
    return isset($current_resource_data['assetIri']) ? $current_resource_data['assetIri'] : '';
}

function render_resource_title() {
    global $current_resource_data;
    return isset($current_resource_data['title']) ? $current_resource_data['title'] : '';
}

function render_resource_description() {
    global $current_resource_data;
    return isset($current_resource_data['description']) ? $current_resource_data['description'] : '';
}

function render_resource_type() {
    global $current_resource_data;
    return isset($current_resource_data['type']) ? $current_resource_data['type'] : '';
}

function render_resource_modifiedOn() {
    global $current_resource_data;
    if (!isset($current_resource_data['modifiedOn']) || empty($current_resource_data['modifiedOn'])) {
        return '';
    }
    $date = DateTime::createFromFormat('Y-m-d', $current_resource_data['modifiedOn']);
    return $date ? $date->format('d/m/Y') : $current_resource_data['modifiedOn'];
}

function render_resource_issuedOn() {
    global $current_resource_data;
    if (!isset($current_resource_data['issuedOn']) || empty($current_resource_data['issuedOn'])) {
        return '';
    }
    $date = DateTime::createFromFormat('Y-m-d', $current_resource_data['issuedOn']);
    return $date ? $date->format('d/m/Y') : $current_resource_data['issuedOn'];
}

function render_resource_versionInfo() {
    global $current_resource_data;
    return isset($current_resource_data['versionInfo']) ? $current_resource_data['versionInfo'] : '';
}

function render_resource_rightsHolder() {
    global $current_resource_data;
    if (!isset($current_resource_data['rightsHolder']) || !is_array($current_resource_data['rightsHolder'])) {
        return '';
    }
    $holder = $current_resource_data['rightsHolder'];
    if (isset($holder['iri']) && isset($holder['summary'])) {
        return '<a href="' . esc_url($holder['iri']) . '" alt="' . esc_attr($holder['summary']) . '">' . esc_html($holder['summary']) . '</a>';
    }
    return '';
}

function render_resource_labels() {
    global $current_resource_data;
    if (!isset($current_resource_data['labels']) || !is_array($current_resource_data['labels'])) {
        return '';
    }
    
    $odd_labels = [];
    foreach ($current_resource_data['labels'] as $index => $label) {
        if ($index % 2 == 1) { // Solo indici dispari (1, 3, 5, ...)
            $odd_labels[] = '<li>' . esc_html($label) . '</li>';
        }
    }
    
    if (empty($odd_labels)) {
        return '';
    }
    
    return '<ul>' . implode('', $odd_labels) . '</ul>';
}

function render_resource_status() {
    global $current_resource_data;
    if (!isset($current_resource_data['status']) || !is_array($current_resource_data['status'])) {
        return '';
    }
    return implode(', ', $current_resource_data['status']);
}

function render_resource_contactPoint_iri() {
    global $current_resource_data;
    if (!isset($current_resource_data['contactPoint']) || !is_array($current_resource_data['contactPoint']) || !isset($current_resource_data['contactPoint']['iri'])) {
        return '';
    }
    $iri = $current_resource_data['contactPoint']['iri'];
    return '<a href="' . esc_url($iri) . '" alt="' . esc_attr($iri) . '">' . esc_html($iri) . '</a>';
}

function render_resource_contactPoint_summary() {
    global $current_resource_data;
    if (!isset($current_resource_data['contactPoint']) || !is_array($current_resource_data['contactPoint']) || !isset($current_resource_data['contactPoint']['summary'])) {
        return '';
    }
    $summary = $current_resource_data['contactPoint']['summary'];
    $display_text = str_replace('mailto:', '', $summary);
    return '<a href="' . esc_url($summary) . '" alt="' . esc_attr($display_text) . '">' . esc_html($display_text) . '</a>';
}

function render_resource_publishers() {
    global $current_resource_data;
    if (!isset($current_resource_data['publishers']) || !is_array($current_resource_data['publishers'])) {
        return '';
    }
    
    $links = [];
    foreach ($current_resource_data['publishers'] as $publisher) {
        if (isset($publisher['iri']) && isset($publisher['summary'])) {
            $links[] = '<a href="' . esc_url($publisher['iri']) . '" alt="' . esc_attr($publisher['summary']) . '">' . esc_html($publisher['summary']) . '</a>';
        }
    }
    return implode(', ', $links);
}

function render_resource_creators() {
    global $current_resource_data;
    if (!isset($current_resource_data['creators']) || !is_array($current_resource_data['creators'])) {
        return '';
    }
    
    $links = [];
    foreach ($current_resource_data['creators'] as $creator) {
        if (isset($creator['iri']) && isset($creator['summary'])) {
            $links[] = '<a href="' . esc_url($creator['iri']) . '" alt="' . esc_attr($creator['summary']) . '">' . esc_html($creator['summary']) . '</a>';
        }
    }
    return implode(', ', $links);
}

function render_resource_languages() {
    global $current_resource_data;
    if (!isset($current_resource_data['languages']) || !is_array($current_resource_data['languages'])) {
        return '';
    }
    
    $language_names = [];
    foreach ($current_resource_data['languages'] as $language_url) {
        if (strpos($language_url, '/ITA') !== false) {
            $language_names[] = 'Italiano';
        } elseif (strpos($language_url, '/ENG') !== false) {
            $language_names[] = 'Inglese';
        } else {
            $language_names[] = $language_url; // fallback per lingue non riconosciute
        }
    }
    return implode(', ', $language_names);
}

function render_resource_themes() {
    global $current_resource_data;
    if (!isset($current_resource_data['themes']) || !is_array($current_resource_data['themes'])) {
        return '';
    }
    
    $theme_labels = [];
    foreach ($current_resource_data['themes'] as $theme_url) {
        $label = ThemeDataHelper::getLabelItByUrl($theme_url);
        if ($label) {
            $theme_labels[] = $label;
        } else {
            $theme_labels[] = $theme_url; // fallback se non trovato nel mapping
        }
    }
    return implode(', ', $theme_labels);
}

function render_resource_type_button() {
    global $current_resource_data;
    if (!isset($current_resource_data['type'])) {
        return '<button class="btn cnd-btn-primary" aria-label="Tipologia non disponibile">Tipologia non disponibile</button>';
    }
    
    $type = $current_resource_data['type'];
    
    switch ($type) {
        case 'ONTOLOGY':
            return '<button class="btn cnd-btn-primary" aria-label="Ontologia">Ontologia</button>';
        case 'CONTROLLED_VOCABULARY':
            return '<button class="btn cnd-btn-primary" aria-label="Vocabolario Controllato">Vocabolario Controllato</button>';
        case 'SCHEMA':
            return '<button class="btn cnd-btn-primary" aria-label="Schema">Schema</button>';
        default:
            return '<button class="btn cnd-btn-primary" aria-label="Tipologia non disponibile">Tipologia non disponibile</button>';
    }
}

function render_resource_type_css() {
    global $current_resource_data;
    if (!isset($current_resource_data['type'])) {
        return '<style>
.cnd-btn-primary { 
         background-color: #000;         
}
.cnd-dtl-bg {  
        background-color: #FFF;        
 }         
.cnd-progress-cnt {             
         background-color: #DDD;         
}         
.cnd-progress-bar {             
         background-color: #000;         
}     
</style>';
    }
    
    $type = $current_resource_data['type'];
    
    switch ($type) {
        case 'ONTOLOGY':
            return '<style>
.cnd-btn-primary { 
         background-color: #0043E3;         
}
.cnd-dtl-bg {  
        background-color: #F2F7FC;        
 }         
.cnd-progress-cnt {             
         background-color: #D3D9EE;         
}         
.cnd-progress-bar {             
         background-color: #0043E3;         
}     
</style>';
        case 'CONTROLLED_VOCABULARY':
            return '<style>
.cnd-btn-primary { 
         background-color: #077F7B;         
}
.cnd-dtl-bg {  
        background-color: #F7FFFF;        
 }         
.cnd-progress-cnt {             
         background-color: #52E0DB;         
}         
.cnd-progress-bar {             
         background-color: #09AFA9;         
}     
</style>';
        case 'SCHEMA':
            return '<style>
.cnd-btn-primary { 
         background-color: #EBA704;         
}
.cnd-dtl-bg {  
        background-color: #FFFDF6;        
 }         
.cnd-progress-cnt {             
         background-color: #FFF8E6;         
}         
.cnd-progress-bar {             
         background-color: #FFB400;         
}     
</style>';
        default:
            return '<style>
.cnd-btn-primary { 
         background-color: #000;         
}
.cnd-dtl-bg {  
        background-color: #FFF;        
 }         
.cnd-progress-cnt {             
         background-color: #DDD;         
}         
.cnd-progress-bar {             
         background-color: #000;         
}     
</style>';
    }
}

function render_resource_accrualPeriodicity() {
    global $current_resource_data;
    if (!isset($current_resource_data['accrualPeriodicity']) || empty($current_resource_data['accrualPeriodicity'])) {
        return '';
    }
    
    $accrualPeriodicity = $current_resource_data['accrualPeriodicity'];
    
    // Map IRREG to "Irregolare"
    if ($accrualPeriodicity === 'http://publications.europa.eu/resource/authority/frequency/IRREG') {
        return 'Irregolare';
    }
    
    return '';
}

function render_resource_prefix() {
    global $current_resource_data;
    return isset($current_resource_data['prefix']) ? $current_resource_data['prefix'] : '';
}

function render_resource_projects() {
    global $current_resource_data;
    if (!isset($current_resource_data['projects']) || !is_array($current_resource_data['projects'])) {
        return '';
    }
    
    $links = [];
    foreach ($current_resource_data['projects'] as $project) {
        if (isset($project['iri']) && isset($project['summary'])) {
            $links[] = '<a href="' . esc_url($project['iri']) . '" alt="' . esc_attr($project['summary']) . '">' . esc_html($project['summary']) . '</a>';
        }
    }
    return implode(', ', $links);
}