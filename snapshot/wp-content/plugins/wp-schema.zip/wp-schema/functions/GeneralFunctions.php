<?php 
function fetch_stats($year = null) {
    // Se l'anno non è fornito, utilizza l'anno corrente
    if (is_null($year)) {
        $year = date('Y');
    }

    $api_url = 'https://ndc-dev.apps.cloudpub.testedev.istat.it/api/semantic-assets/stats?year=' . urlencode($year);
    $response = file_get_contents($api_url);
    return json_decode($response, true);
}

function formatValue($value) {
    // Aggiunge il segno + ai valori >= 0
    return ($value >= 0 ? '+' : '') . $value;
}

function GetStatsTotal($year = null) {
    $stats = fetch_stats($year);
    return $stats['total']['current'];
}

function GetStatsTotalOverLastYear($year = null) {
    $stats = fetch_stats($year);
    return formatValue($stats['total']['incrementOverLastYear']);
}

function GetStatsTotalPercentageOverLastYear($year = null) {
    $stats = fetch_stats($year);
    return formatValue($stats['total']['incrementPercentageOverLastYear']);
}

function GetStatsCV($year = null) {
    $stats = fetch_stats($year);
    return $stats['controlledVocabulary']['current'];
}

function GetStatsCVOverLastYear($year = null) {
    $stats = fetch_stats($year);
    return formatValue($stats['controlledVocabulary']['incrementOverLastYear']);
}

function GetStatsCVPercentageOverLastYear($year = null) {
    $stats = fetch_stats($year);
    return formatValue($stats['controlledVocabulary']['incrementPercentageOverLastYear']);
}

function GetStatsOntology($year = null) {
    $stats = fetch_stats($year);
    return $stats['ontology']['current'];
}

function GetStatsOntologyOverLastYear($year = null) {
    $stats = fetch_stats($year);
    return formatValue($stats['ontology']['incrementOverLastYear']);
}

function GetStatsOntologyPercentageOverLastYear($year = null) {
    $stats = fetch_stats($year);
    return formatValue($stats['ontology']['incrementPercentageOverLastYear']);
}

function GetStatsSchema($year = null) {
    $stats = fetch_stats($year);
    return $stats['schema']['current'];
}

function GetStatsSchemaOverLastYear($year = null) {
    $stats = fetch_stats($year);
    return formatValue($stats['schema']['incrementOverLastYear']);
}

function GetStatsSchemaPercentageOverLastYear($year = null) {
    $stats = fetch_stats($year);
    return formatValue($stats['schema']['incrementPercentageOverLastYear']);
}

function PrintAllStats($year = null) {
    $stats = fetch_stats($year);
    echo "<pre>";
    print_r($stats);
    echo "</pre>";
}

// Shortcode per statistiche GitHub del cookiecutter
add_shortcode('cookiecutter_stats', 'render_cookiecutter_stats');

function render_cookiecutter_stats($atts) {
    $atts = shortcode_atts(array(
        'show_forks' => 'true',
        'show_stars' => 'true',
        'show_watchers' => 'true',
        'show_contributors' => 'true',
        'show_languages' => 'true',
        'show_commits' => 'true'
    ), $atts);
    
    // Fetch dati GitHub API
    $github_data = fetch_github_repo_data();
    
    if (!$github_data) {
        return '<div class="cookiecutter-stats-error">Errore nel caricamento delle statistiche GitHub</div>';
    }
    
    ob_start();
    ?>
    <div class="cookiecutter-stats-container">
        <h3>📊 Statistiche Repository dati-semantic-cookiecutter</h3>
        <div class="stats-grid">
            
            <?php if ($atts['show_stars'] === 'true'): ?>
            <div class="stat-card">
                <div class="stat-icon">⭐</div>
                <div class="stat-content">
                    <div class="stat-number"><?php echo esc_html($github_data['stargazers_count']); ?></div>
                    <div class="stat-label">Stars</div>
                </div>
            </div>
            <?php endif; ?>
            
            <?php if ($atts['show_forks'] === 'true'): ?>
            <div class="stat-card">
                <div class="stat-icon">🍴</div>
                <div class="stat-content">
                    <div class="stat-number"><?php echo esc_html($github_data['forks_count']); ?></div>
                    <div class="stat-label">Forks</div>
                </div>
            </div>
            <?php endif; ?>
            
            <?php if ($atts['show_watchers'] === 'true'): ?>
            <div class="stat-card">
                <div class="stat-icon">👀</div>
                <div class="stat-content">
                    <div class="stat-number"><?php echo esc_html($github_data['watchers_count']); ?></div>
                    <div class="stat-label">Watchers</div>
                </div>
            </div>
            <?php endif; ?>
            
            <?php if ($atts['show_commits'] === 'true'): ?>
            <div class="stat-card">
                <div class="stat-icon">📝</div>
                <div class="stat-content">
                    <div class="stat-number"><?php echo esc_html($github_data['commits_count']); ?></div>
                    <div class="stat-label">Commits</div>
                </div>
            </div>
            <?php endif; ?>
            
        </div>
        
        <?php if ($atts['show_contributors'] === 'true' && !empty($github_data['contributors'])): ?>
        <div class="contributors-section">
            <h4>👥 Contributori</h4>
            <div class="contributors-list">
                <?php foreach ($github_data['contributors'] as $contributor): ?>
                <div class="contributor-item">
                    <img src="<?php echo esc_url($contributor['avatar_url']); ?>" 
                         alt="<?php echo esc_attr($contributor['login']); ?>" 
                         class="contributor-avatar">
                    <div class="contributor-info">
                        <a href="<?php echo esc_url($contributor['html_url']); ?>" 
                           target="_blank" class="contributor-name">
                            <?php echo esc_html($contributor['login']); ?>
                        </a>
                        <div class="contributor-commits">
                            <?php echo esc_html($contributor['contributions']); ?> commits
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>
        
        <?php if ($atts['show_languages'] === 'true' && !empty($github_data['languages'])): ?>
        <div class="languages-section">
            <h4>💻 Linguaggi</h4>
            <div class="languages-chart">
                <?php 
                $total_bytes = array_sum($github_data['languages']);
                foreach ($github_data['languages'] as $language => $bytes): 
                    $percentage = ($bytes / $total_bytes) * 100;
                ?>
                <div class="language-item">
                    <div class="language-name"><?php echo esc_html($language); ?></div>
                    <div class="language-bar">
                        <div class="language-fill" style="width: <?php echo esc_attr($percentage); ?>%"></div>
                    </div>
                    <div class="language-percentage"><?php echo esc_html(round($percentage, 1)); ?>%</div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>
        
        <div class="repo-info">
            <p><strong>Repository:</strong> 
                <a href="<?php echo esc_url($github_data['html_url']); ?>" target="_blank">
                    <?php echo esc_html($github_data['full_name']); ?>
                </a>
            </p>
            <p><strong>Ultimo aggiornamento:</strong> 
                <?php echo esc_html(date('d/m/Y H:i', strtotime($github_data['updated_at']))); ?>
            </p>
            <p><strong>Creato:</strong> 
                <?php echo esc_html(date('d/m/Y', strtotime($github_data['created_at']))); ?>
            </p>
        </div>
    </div>
    
    <style>
    .cookiecutter-stats-container {
        background: #fff;
        border-radius: 8px;
        padding: 20px;
        box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        margin: 20px 0;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    }
    
    .cookiecutter-stats-container h3 {
        margin-bottom: 20px;
        color: #333;
        border-bottom: 2px solid #007cba;
        padding-bottom: 10px;
    }
    
    .stats-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
        gap: 15px;
        margin-bottom: 30px;
    }
    
    .stat-card {
        background: #f8f9fa;
        border-radius: 8px;
        padding: 15px;
        text-align: center;
        border: 1px solid #e9ecef;
        transition: transform 0.2s ease;
    }
    
    .stat-card:hover {
        transform: translateY(-2px);
        box-shadow: 0 4px 12px rgba(0,0,0,0.1);
    }
    
    .stat-icon {
        font-size: 24px;
        margin-bottom: 8px;
    }
    
    .stat-number {
        font-size: 24px;
        font-weight: bold;
        color: #007cba;
        margin-bottom: 5px;
    }
    
    .stat-label {
        font-size: 14px;
        color: #666;
        text-transform: uppercase;
        letter-spacing: 0.5px;
    }
    
    .contributors-section, .languages-section {
        margin-bottom: 25px;
    }
    
    .contributors-section h4, .languages-section h4 {
        margin-bottom: 15px;
        color: #333;
        font-size: 18px;
    }
    
    .contributors-list {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
        gap: 10px;
    }
    
    .contributor-item {
        display: flex;
        align-items: center;
        padding: 10px;
        background: #f8f9fa;
        border-radius: 6px;
        border: 1px solid #e9ecef;
    }
    
    .contributor-avatar {
        width: 40px;
        height: 40px;
        border-radius: 50%;
        margin-right: 10px;
    }
    
    .contributor-name {
        font-weight: bold;
        color: #007cba;
        text-decoration: none;
    }
    
    .contributor-name:hover {
        text-decoration: underline;
    }
    
    .contributor-commits {
        font-size: 12px;
        color: #666;
    }
    
    .languages-chart {
        background: #f8f9fa;
        border-radius: 6px;
        padding: 15px;
        border: 1px solid #e9ecef;
    }
    
    .language-item {
        display: flex;
        align-items: center;
        margin-bottom: 10px;
    }
    
    .language-name {
        width: 100px;
        font-weight: bold;
        color: #333;
    }
    
    .language-bar {
        flex: 1;
        height: 20px;
        background: #e9ecef;
        border-radius: 10px;
        margin: 0 10px;
        overflow: hidden;
    }
    
    .language-fill {
        height: 100%;
        background: linear-gradient(90deg, #007cba, #0056b3);
        transition: width 0.3s ease;
    }
    
    .language-percentage {
        width: 50px;
        text-align: right;
        font-size: 14px;
        color: #666;
    }
    
    .repo-info {
        background: #f8f9fa;
        border-radius: 6px;
        padding: 15px;
        border: 1px solid #e9ecef;
        font-size: 14px;
    }
    
    .repo-info p {
        margin: 5px 0;
        color: #333;
    }
    
    .repo-info a {
        color: #007cba;
        text-decoration: none;
    }
    
    .repo-info a:hover {
        text-decoration: underline;
    }
    
    .cookiecutter-stats-error {
        background: #f8d7da;
        color: #721c24;
        padding: 15px;
        border-radius: 6px;
        border: 1px solid #f5c6cb;
        margin: 20px 0;
    }
    </style>
    <?php
    return ob_get_clean();
}

// Funzione per fetchare i dati GitHub
function fetch_github_repo_data() {
    $repo_url = 'https://api.github.com/repos/teamdigitale/dati-semantic-cookiecutter';
    
    // Headers per GitHub API
    $context = stream_context_create([
        'http' => [
            'method' => 'GET',
            'header' => [
                'User-Agent: WordPress-Plugin',
                'Accept: application/vnd.github.v3+json'
            ]
        ]
    ]);
    
    $response = @file_get_contents($repo_url, false, $context);
    
    if ($response === false) {
        return false;
    }
    
    $repo_data = json_decode($response, true);
    
    if (!$repo_data) {
        return false;
    }
    
    // Fetch contributors
    $contributors_url = 'https://api.github.com/repos/teamdigitale/dati-semantic-cookiecutter/contributors';
    $contributors_response = @file_get_contents($contributors_url, false, $context);
    $contributors = $contributors_response ? json_decode($contributors_response, true) : [];
    
    // Fetch languages
    $languages_url = 'https://api.github.com/repos/teamdigitale/dati-semantic-cookiecutter/languages';
    $languages_response = @file_get_contents($languages_url, false, $context);
    $languages = $languages_response ? json_decode($languages_response, true) : [];
    
    // Fetch commits count
    $commits_url = 'https://api.github.com/repos/teamdigitale/dati-semantic-cookiecutter/commits';
    $commits_response = @file_get_contents($commits_url, false, $context);
    $commits = $commits_response ? json_decode($commits_response, true) : [];
    
    return [
        'full_name' => $repo_data['full_name'],
        'html_url' => $repo_data['html_url'],
        'stargazers_count' => $repo_data['stargazers_count'],
        'forks_count' => $repo_data['forks_count'],
        'watchers_count' => $repo_data['watchers_count'],
        'created_at' => $repo_data['created_at'],
        'updated_at' => $repo_data['updated_at'],
        'contributors' => $contributors,
        'languages' => $languages,
        'commits_count' => count($commits)
    ];
}